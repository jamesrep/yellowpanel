
export function yellowpanelApiUiPluginController($http, $scope, $timeout, chrome, Notifier) 
{

  
}